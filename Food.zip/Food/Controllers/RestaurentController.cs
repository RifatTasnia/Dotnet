﻿using Food.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Food.Controllers
{
    public class RestaurentController : Controller
    {
        // GET: Restaurent
        
        public ActionResult Login()
        {
            return View();
        }

        public ActionResult Home()
        {
            return View();
        }

        public ActionResult ResView()
        {
            return View();
        }

        public ActionResult AdminView()
        {
            return View();
        }

        public ActionResult EmployeeView()
        {
            return View();
        }


        //-----------------------------------------------------------Create Restaurant

        [HttpGet]
        public ActionResult CreateRes()
        {
            return View();
        }



        //-------------------------------------------------------------Create Restaurant

        [HttpPost]
        public ActionResult CreateRes(Restaurant restaurant)
        {
            var db = new FoodEntities();
            db.Restaurants.Add(restaurant);
            db.SaveChanges();
            return View("CreateRes");
        }


        //---------------------------------------------------------Create Collection Request

        [HttpGet]
        public ActionResult CreateCollect_Req()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateCollect_Req(Collect_Request request)
        {
            var db = new FoodEntities();
            db.Collect_Request.Add(request);
            db.SaveChanges();
            return RedirectToAction("Current_Collect_Request");
            return RedirectToAction("Current_Collect_Request_for_res");
        }

        public ActionResult Current_Collect_Request()       //---------------list for restaurant
        {
            var db = new FoodEntities();
            var collect = db.Collect_Request.ToList();
            return View(collect);
        }

        public ActionResult EditRequest(int? id)  //--------------------Edit for restaurant view
        {
            var db = new FoodEntities();
            var request = (from r in db.Collect_Request 
                           where r.Id == id 
                           select r).SingleOrDefault();
            return View(request);
        }
        [HttpPost]
        public ActionResult EditRequest(Collect_Request updaterequest)
        {
            var db = new FoodEntities();
            var request = (from r in db.Collect_Request 
                           where r.Id == updaterequest.Id 
                           select r).SingleOrDefault();
            request.Restaurant_Id = updaterequest.Restaurant_Id;
            request.Food_Item = updaterequest.Food_Item;
            request.Amount = updaterequest.Amount;
            request.Request_Time = updaterequest.Request_Time;
            request.Max_Preserve_Time = updaterequest.Max_Preserve_Time;
            db.SaveChanges();
            return RedirectToAction("Current_Collect_Request");
        }

        public ActionResult DeleteRequest(int id)    //-------------------------Delete for restaurant view
        {
            var db = new FoodEntities();
            var request = (from r in db.Collect_Request 
                           where r.Id == id 
                           select r).SingleOrDefault();
            db.Collect_Request.Remove(request);
            db.SaveChanges();
            return RedirectToAction("Current_Collect_Request");
        }


        public ActionResult DetailsRequest(int id)    //--------------------Details for restaurant view
        {
            var db = new FoodEntities();
            var request = from r in db.Collect_Request 
                           where r.Id == id 
                           select r;
            return View(request.SingleOrDefault());
        }





        //----------------------------------------------------------Request for Admin View
        public ActionResult Current_Collect_Request_for_res()   //----------------list for admin 
        {
            var db = new FoodEntities();
            var collect = db.Collect_Request.ToList();
            return View(collect);
        }


        public ActionResult EditRequest_foradmin(int? id)  //-----------------------Edit for Admin view
        {
            var db = new FoodEntities();
            var request = (from r in db.Collect_Request
                           where r.Id == id
                           select r).SingleOrDefault();
            return View(request);
        }
        [HttpPost]
        public ActionResult EditRequest_foradmin(Collect_Request updaterequest)
        {
            var db = new FoodEntities();
            var request = (from r in db.Collect_Request
                           where r.Id == updaterequest.Id
                           select r).SingleOrDefault();
            request.Restaurant_Id = updaterequest.Restaurant_Id;
            request.Food_Item = updaterequest.Food_Item;
            request.Amount = updaterequest.Amount;
            request.Request_Time = updaterequest.Request_Time;
            request.Max_Preserve_Time = updaterequest.Max_Preserve_Time;
            db.SaveChanges();
            return RedirectToAction("Current_Collect_Request_for_res");
        }

        public ActionResult DeleteRequest_foradmin(int id)    //----------------------Delete for Admin view
        {
            var db = new FoodEntities();
            var request = (from r in db.Collect_Request
                           where r.Id == id
                           select r).SingleOrDefault();
            db.Collect_Request.Remove(request);
            db.SaveChanges();
            return RedirectToAction("Current_Collect_Request_for_res");
        }


        public ActionResult DetailsRequest_foradmin(int id)    //--------------------Details for Admin view
        {
            var db = new FoodEntities();
            var request = from r in db.Collect_Request
                          where r.Id == id
                          select r;
            return View(request.SingleOrDefault());
        }




        //------------------------------------------------------Current Collection Task for Admin
        public ActionResult CollectionList_forAdmin()   //-----------------Current Collection List
        {
            var db = new FoodEntities();
            var task = db.Collection_Task.ToList();
            return View(task);
        }



        public ActionResult EditRequest_foradmin_collection(int? id)  //----Collection Edit for Admin view
        {
            var db = new FoodEntities();
            var collection = (from r in db.Collection_Task
                           where r.Id == id
                           select r).SingleOrDefault();
            return View(collection);
        }
        [HttpPost]
        public ActionResult EditRequest_foradmin_collection(Collection_Task updatecollection)
        {
            var db = new FoodEntities();
            var collection = (from r in db.Collection_Task
                           where r.Id == updatecollection.Id
                           select r).SingleOrDefault();
            collection.Food_Item = updatecollection.Food_Item;
            collection.Amount = updatecollection.Amount;
            db.SaveChanges();
            return RedirectToAction("CollectionList_forAdmin");
        }

        public ActionResult DeleteRequest_foradmin_collection(int id)    //Collection Delete for Admin view
        {
            var db = new FoodEntities();
            var coll = (from r in db.Collection_Task
                           where r.Id == id
                           select r).SingleOrDefault();
            db.Collection_Task.Remove(coll);
            db.SaveChanges();
            return RedirectToAction("CollectionList_forAdmin");
        }


        public ActionResult DetailsRequest_foradmin_collection(int id)    //Collection Details for Admin view
        {
            var db = new FoodEntities();
            var request = from r in db.Collection_Task
                          where r.Id == id
                          select r;
            return View(request.SingleOrDefault());
        }




        //---------------------------------------------------Current Distribution Task

        public ActionResult DistributionList_forAdmin()  //---------------Current Distribution List
        {
            var db = new FoodEntities();
            var dis = db.Distribution_Task.ToList();
            return View(dis);
        }



        public ActionResult EditRequest_foradmin_distribution(int? id)  //Collection Edit for Admin view
        {
            var db = new FoodEntities();
            var distribution = (from d in db.Distribution_Task
                              where d.Id == id
                              select d).SingleOrDefault();
            return View(distribution);
        }
        [HttpPost]
        public ActionResult EditRequest_foradmin_distribution(Distribution_Task updatedistribution)
        {
            var db = new FoodEntities();
            var distribution = (from d in db.Distribution_Task
                              where d.Id == updatedistribution.Id
                              select d).SingleOrDefault();
            distribution.Destination = updatedistribution.Destination;
            distribution.Employee_Id = updatedistribution.Employee_Id;
            distribution.Distribution_Time = updatedistribution.Distribution_Time;
            distribution.Food_Item = updatedistribution.Food_Item;
            distribution.Amont = updatedistribution.Amont;
            return RedirectToAction("DistributionList_forAdmin");
        }

        public ActionResult DeleteRequest_foradmin_distribution(int id)    //Collection Delete for Admin view
        {
            var db = new FoodEntities();
            var distribution = (from d in db.Distribution_Task
                        where d.Id == id
                        select d).SingleOrDefault();
            db.Distribution_Task.Remove(distribution);
            db.SaveChanges();
            return RedirectToAction("DistributionList_forAdmin");
        }


        public ActionResult DetailsRequest_foradmin_distribution(int id)    //Collection Details for Admin view
        {
            var db = new FoodEntities();
            var distribution = from d in db.Distribution_Task
                          where d.Id == id
                          select d;
            return View(distribution.SingleOrDefault());
        }



        //------------------------------------------------------------Create Collection Task

        [HttpGet]
        public ActionResult CreateCollection()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateCollection(Collection_Task collection)
        {
            var db = new FoodEntities();
            db.Collection_Task.Add(collection);
            db.SaveChanges();
            return RedirectToAction("CollectionList_forAdmin");
        }

        public ActionResult CollectionList()
        {
            var db = new FoodEntities();
            var task = db.Collection_Task.ToList();
            return View(task);
        }




        //-------------------------------------------------------------Create Employee Table

        [HttpGet]
        public ActionResult CreateEmployee()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateEmployee(Employee employee)
        {
            var db = new FoodEntities();
            db.Employees.Add(employee);
            db.SaveChanges();
            return View("CreateEmployee");
        }


        //-----------------------------------------------------------Distribution

        [HttpGet]
        public ActionResult CreateDistribution()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateDistribution(Distribution_Task distribution)
        {
            var db = new FoodEntities();
            db.Distribution_Task.Add(distribution);
            db.SaveChanges();
            return RedirectToAction("DistributionList_forAdmin");
        }

        public ActionResult DistributionList()
        {
            var db = new FoodEntities();
            var dis = db.Distribution_Task.ToList();
            return View(dis);
        }



    }
}